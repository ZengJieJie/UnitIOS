//
//  BridgingIOS.m
//  UnityFramework
//
//  Created by 发行二部 on 2024/12/5.
//











#import <Foundation/Foundation.h>
#import "BridgingIOS.h"


@implementation FrameworkLibAPI

id<BridgingIOS> api = NULL;
+(void) registerAPIforNativeCalls:(id<BridgingIOS>) aApi
{
    api = aApi;
}

@end


extern "C" {
    
    

     //调用打点
    void _trackEvent(const char *eventName, const char *params) {
        NSLog(@"33333");
        
            [api trackEvent:eventName params:params];
       
    }
    //调用插屏有CD
    void _ShowInsertAdByStartCd() {
      
            [api ShowInsertAdByStartCd];
       
    }
   //调用激励视频
    void _ShowRewardVideo() {
       
            [api ShowRewardVideo];
        
    }
}
