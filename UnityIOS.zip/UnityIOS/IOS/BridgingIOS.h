//
//  BridgingIOS.h
//  UnityFramework
//
//  Created by 发行二部 on 2024/12/5.
//




#import <Foundation/Foundation.h>
@protocol BridgingIOS

@required

- (void)ShowInsertAdByStartCd;
- (void)ShowRewardVideo;
- (void)trackEvent:(const char *)eventName params:(const char *)params;

@end

__attribute__ ((visibility("default")))

@interface FrameworkLibAPI : NSObject
// call it any time after UnityFrameworkLoad to set object implementing NativeCallsProtocol methods
+(void) registerAPIforNativeCalls:(id<BridgingIOS>) aApi;

@end
