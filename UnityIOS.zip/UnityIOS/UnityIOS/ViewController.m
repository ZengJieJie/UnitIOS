//
//  ViewController.m
//  UnityIOS
//
//  Created by 发行二部 on 2024/12/5.
//

#import "ViewController.h"
#import "AppDelegate.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //加载Unity游戏
    AppDelegate *appDelegate = (AppDelegate *)([UIApplication sharedApplication].delegate);
       [appDelegate showUnityView];
}


@end
