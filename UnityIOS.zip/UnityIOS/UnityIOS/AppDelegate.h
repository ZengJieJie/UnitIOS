//
//  AppDelegate.h
//  Parkingpleaseattention
//
//  Created by 发行二部 on 2024/10/14.
//

#import <UIKit/UIKit.h>
#include <UnityFramework/UnityFramework.h>
#import <UnityFramework/BridgingIOS.h>
@interface AppDelegate : UIResponder <UIApplicationDelegate,UnityFrameworkListener,BridgingIOS>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, strong) UnityFramework *ufw;
- (void)sendMessageWithName:(const char*)goName functionName:(const char*) functionName message:(const char*)msg;
- (void)showUnityView;

- (void)showNativeView;

@end

