//
//  AppDelegate.m
//  Parkingpleaseattention
//
//  Created by 发行二部 on 2024/10/14.
//

#import "AppDelegate.h"
#import "AdMgr.h"
#import <AdSupport/AdSupport.h>
#import <AppTrackingTransparency/AppTrackingTransparency.h>
#import <Firebase.h>
#import "FBSDKCoreKit/FBSDKCoreKit.h"
#import <AFNetworking/AFNetworking.h>
#import "JsToIOS.h"

#define INTERSTITIAL_AD_ENABLED true // 插屏广告
#define REWARDED_AD_ENABLED true     // 激励广告


UIKIT_STATIC_INLINE UnityFramework* UnityFrameworkLoad()
{
    NSString* bundlePath = nil;
    bundlePath = [[NSBundle mainBundle] bundlePath];
    bundlePath = [bundlePath stringByAppendingString: @"/Frameworks/UnityFramework.framework"];

    NSBundle* bundle = [NSBundle bundleWithPath: bundlePath];
    if ([bundle isLoaded] == false) [bundle load];

    UnityFramework* ufw = [bundle.principalClass getInstance];
    if (![ufw appController])
    {
        // unity is not initialized
        [ufw setExecuteHeader: &_mh_execute_header];
    }
    return ufw;
}

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    // Override point for customization after application launch.
    [self initUnity];
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setObject:launchOptions forKey:@"launchOptions"];
    [userDefaults synchronize];
    [[AdMgr getInstance]init:self.window.rootViewController];
        //firebase初始化
        [FIRApp configure];
    [[NSUserDefaults standardUserDefaults]setBool:true forKey:@"_debug_analytics"];
        //facebook
        [[FBSDKApplicationDelegate sharedInstance]application:application didFinishLaunchingWithOptions:launchOptions];
   
    return YES;
}


#pragma mark - Unity

- (BOOL)unityIsInitialized
{
    return [self ufw] && [[self ufw] appController];
}

- (void)initUnity
{
    /* 判断Unity 是否已经初始化 */
    if ([self unityIsInitialized]) return;
    /* 初始化Unity */
    self.ufw = UnityFrameworkLoad();
    [self.ufw setDataBundleId:"com.unity3d.framework"];
    [self.ufw registerFrameworkListener:self];
//    [NSClassFromString(@"FrameworkLibAPI") registerAPIforNativeCalls:self];
    [NSClassFromString(@"FrameworkLibAPI") registerAPIforNativeCalls:self];
    NSString *argvStr = [[NSUserDefaults standardUserDefaults] valueForKey:@"argv"];
    char **argv;
    sscanf([argvStr cStringUsingEncoding:NSUTF8StringEncoding], "%p",&argv);
    int argc = [[[NSUserDefaults standardUserDefaults] valueForKey:@"argc"] intValue];
    NSDictionary *launchOptions = [[NSUserDefaults standardUserDefaults] valueForKey:@"launchOptions"];
    [self.ufw runEmbeddedWithArgc:argc argv:argv appLaunchOpts:launchOptions];
    
}

- (void)showUnityView
{
    if (![self unityIsInitialized]){
        NSLog(@"Unity 还未初始化");
    }
    
    [self.ufw showUnityWindow];
}


- (void)showNativeView
{
    [self.window makeKeyAndVisible];
}



#pragma mark - UnityFrameworkListener
- (void)unityDidUnload:(NSNotification *)notification
{
    NSLog(@"========== %s ============",__func__);
    [self.window makeKeyAndVisible];
    [[self ufw] unregisterFrameworkListener: self];
    [self setUfw: nil];
}

- (void)unityDidQuit:(NSNotification *)notification
{
    NSLog(@"========== %s ============",__func__);
}


- (void)applicationWillResignActive:(UIApplication *)application {
    [[[self ufw] appController] applicationWillResignActive: application];
}
- (void)applicationDidEnterBackground:(UIApplication *)application {
    [[[self ufw] appController] applicationDidEnterBackground: application];
}
- (void)applicationWillEnterForeground:(UIApplication *)application {
    [[[self ufw] appController] applicationWillEnterForeground: application];
}
- (void)applicationDidBecomeActive:(UIApplication *)application {
    [[[self ufw] appController] applicationDidBecomeActive: application];
   
  [self performSelector:@selector(delayRequestPrivicy) withObject:nil afterDelay:1.0f];//请求权限
  [self performSelector:@selector(checkConnect) withObject:nil afterDelay:3.0f];//判断是否联网
}
- (void)applicationWillTerminate:(UIApplication *)application {
    [[[self ufw] appController] applicationWillTerminate: application];
}

// 实现 ShowInsertAdByStartCd 方法
- (void)ShowInsertAdByStartCd {
    if (INTERSTITIAL_AD_ENABLED) {
        [JsToIOS ShowInsertAdByStartCd];
    }
    
}

// 实现 ShowRewardVideo 方法
- (void)ShowRewardVideo {
    if (REWARDED_AD_ENABLED) {
        [JsToIOS ShowRewardVideo];
    }else{
        
        [self sendMessageWithName:[@"AndroidAdMono" UTF8String]
                             functionName:[@"OnVideoClose" UTF8String]
                                  message:[@"true" UTF8String]];
    }
}



-(void)trackEvent:(const char *)eventName params:(const char *)params{
    
    [JsToIOS TrackEvent:[NSString stringWithCString:eventName encoding:NSUTF8StringEncoding] params:[NSString stringWithCString:params encoding:NSUTF8StringEncoding]];
    
}

-(void)delayRequestPrivicy{
    if (@available(iOS 14.0, *)) {
        NSLog(@"ios14 available");
        [ATTrackingManager requestTrackingAuthorizationWithCompletionHandler:^(ATTrackingManagerAuthorizationStatus status){
            if(ATTrackingManagerAuthorizationStatusAuthorized == status) {
                NSLog(@"获得权限！！");
                dispatch_async(dispatch_get_main_queue(), ^{
                    [[AdMgr getInstance]initSdk:self.window.rootViewController];
                });
                
            } else {
                NSLog(@"拒绝获得权限！！");
                dispatch_async(dispatch_get_main_queue(), ^{
                    [[AdMgr getInstance]initSdk:self.window.rootViewController];
                });
            }
        }];
    } else {
        NSLog(@"ios14  not  available");
        dispatch_async(dispatch_get_main_queue(), ^{
            [[AdMgr getInstance]initSdk:self.window.rootViewController];
        });
    }
    
    NSString *idfa = [[[ASIdentifierManager sharedManager]advertisingIdentifier]UUIDString];
    NSLog(@"我的设备idfa:%@",idfa);
}

-(void)checkConnect{
    AFNetworkReachabilityManager *mgr = [AFNetworkReachabilityManager sharedManager];
    [mgr startMonitoring];
    [mgr setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
            switch (status) {
                case AFNetworkReachabilityStatusNotReachable:
                    NSLog(@" 没有网络");
                    [[AdMgr getInstance]setConnState:NO];
                    break;
                default:
                    NSLog(@" 网络正常");
                    [[AdMgr getInstance]setConnState:YES];
                    break;
            }
    }];
}

- (void)sendMessageWithName:(const char*)goName functionName:(const char*) functionName message:(const char*)msg{
     [self.ufw sendMessageToGOWithName:goName functionName:functionName message:msg];
}

@end




