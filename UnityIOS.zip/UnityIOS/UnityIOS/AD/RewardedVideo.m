//
//  RewardedVideo.m
//  wbxcsa-mobile
//
//  Created by 朱启奔 on 2024/9/14.
//

#import "RewardedVideo.h"

#import "AdMgr.h"
#import <AdjustSdk/AdjustSdk.h>
@interface RewardedVideo()<MARewardedAdDelegate>
@property(nonatomic, strong) UIViewController *rootViewController;
@property(nonatomic, strong) MARewardedAd *rewardedAd;
@property(nonatomic, assign) NSInteger retryAttempt;
@property(nonatomic, assign) BOOL rewardValid;
@end

@implementation RewardedVideo

-(instancetype)initAd:(NSString *)adSlotId rootViewController:(UIViewController *)rootViewController
{
    self.rewardedAd = [MARewardedAd sharedWithAdUnitIdentifier:adSlotId];
    self.rewardedAd.delegate = self;
    [self.rewardedAd loadAd];
    return self;
}

-(void)show
{
    self.rewardValid = NO;
    if ([self.rewardedAd isReady]) {
        [self.rewardedAd showAd];
    }else
    {
        [[AdMgr getInstance] videoEnd:NO];
        NSLog(@"Max RewardedAd未准备好");
        [self.rewardedAd loadAd];
    }
}

- (void)didLoadAd:(MAAd *)ad{
    NSLog(@"Max RewardedAd加载成功");
    self.retryAttempt = 0;
//    [self.rewardedAd showAd];
}

- (void)didPayRevenueForAd:(MAAd *)ad
{
  double revenue = ad.revenue; // In USD

  // Miscellaneous data
  NSString *countryCode = [ALSdk shared].configuration.countryCode; // "US" for the United States, etc - Note: Do not confuse this with currency code which is "USD"
  NSString *networkName = ad.networkName; // Display name of the network that showed the ad
  NSString *adUnitId = ad.adUnitIdentifier; // The MAX Ad Unit ID
  MAAdFormat *adFormat = ad.format; // The ad format of the ad (e.g. BANNER, MREC, INTERSTITIAL, REWARDED)
  NSString *placement = ad.placement; // The placement this ad's postbacks are tied to
  NSString *networkPlacement = ad.networkPlacement; // The placement ID from the network that showed the ad
    NSLog(@"收入-%.7f-地区-%@-广告名-%@-Unit ID-%@-广告形式-%@-位置-%@-放置ID-%@", revenue,countryCode,networkName,adUnitId,adFormat,placement,networkPlacement);
    ADJAdRevenue *adRevenue = [[ADJAdRevenue alloc]
                                  initWithSource:@"applovin_max_sdk"];
    [adRevenue setRevenue:revenue currency:@"USD"];
    [adRevenue setAdImpressionsCount:10];
    [adRevenue setAdRevenueNetwork:adFormat.label];
    [adRevenue setAdRevenueUnit:ad.adUnitIdentifier];
    [adRevenue setAdRevenuePlacement:[ALSdk shared].configuration.countryCode];
    [Adjust trackAdRevenue:adRevenue];
}
- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error{
    NSLog(@"Max RewardedAd加载失败:%ld %@",(long)error.code,error.message);
    self.retryAttempt++;
    NSInteger delaySec = pow(2, MIN(6,self.retryAttempt));
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, delaySec*NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        [self.rewardedAd loadAd];
    });
}

- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error{
    NSLog(@"Max RewardedAd播放失败:%ld %@",(long)error.code,error.message);
    [self.rewardedAd loadAd];
}

- (void)didStartRewardedVideoForAd:(MAAd *)ad{
    NSLog(@"Max RewardedAd didStartRewardedVideoForAd");
   
}

- (void)didCompleteRewardedVideoForAd:(MAAd *)ad{
    NSLog(@"Max RewardedAd didCompleteRewardedVideoForAd");
    [self.rewardedAd loadAd];
}

- (void)didRewardUserForAd:(MAAd *)ad withReward:(MAReward *)reward{
    NSLog(@"Max RewardedAd didRewardUserForAd");
    self.rewardValid = YES;
    [[AdMgr getInstance] videoEnd:self.rewardValid];
    [[AdMgr getInstance] setLastAdTime];
    [self.rewardedAd loadAd];
}

- (void)didDisplayAd:(MAAd *)ad{
    NSLog(@"Max RewardedAd didDisplayAd");
}

- (void)didClickAd:(nonnull MAAd *)ad { 
    NSLog(@"Max RewardedAd didDisplayAd111111");
}


- (void)didHideAd:(nonnull MAAd *)ad { 
    NSLog(@"Max RewardedAd didDisplayAd2222222");
}



@end
