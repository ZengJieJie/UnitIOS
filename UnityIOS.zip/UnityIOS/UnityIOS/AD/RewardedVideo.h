//
//  RewardedVideo.h
//  wbxcsa-mobile
//
//  Created by 朱启奔 on 2024/9/14.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <AppLovinSDK/AppLovinSDK.h>
NS_ASSUME_NONNULL_BEGIN

@interface RewardedVideo : NSObject
-(instancetype)initAd:(NSString *)adSlotId rootViewController:(UIViewController *)rootViewController;
-(void)show;
@end

NS_ASSUME_NONNULL_END
