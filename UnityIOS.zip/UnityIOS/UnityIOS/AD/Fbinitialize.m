//
//  Fbinitialize.m
//  Unity-iPhone
//
//  Created by 发行二部 on 2024/12/5.
//

#import "Fbinitialize.h"

#import <Firebase.h>
#import <AFNetworking/AFNetworking.h>
#import "AdMgr.h"
@implementation Fbinitialize
//初始化Firebase和FBSDK
+ (void)fbinitalize:(UIApplication *)application :(NSDictionary *)launchOptions {
    [FIRApp configure];
    [[FBSDKApplicationDelegate sharedInstance]application:application didFinishLaunchingWithOptions:launchOptions];
}
+(void)Netjudgment{
    AFNetworkReachabilityManager *mgr = [AFNetworkReachabilityManager sharedManager];
    [mgr startMonitoring];
    [mgr setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
            switch (status) {
                case AFNetworkReachabilityStatusNotReachable:
                    NSLog(@" 没有网络");
                    [[AdMgr getInstance]setConnState:NO];
                    break;
                default:
                    NSLog(@" 网络正常");
                    [[AdMgr getInstance]setConnState:YES];
                    break;
            }
    }];
    
}
@end
