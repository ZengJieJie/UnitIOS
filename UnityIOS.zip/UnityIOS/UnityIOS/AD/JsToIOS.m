//
//  JsToIOS.m
//  wbxcsa-mobile
//
//  Created by 朱启奔 on 2024/9/14.
//

#import "JsToIOS.h"
#import "AdMgr.h"
#import <Firebase.h>
#import "TenjinSDK.h"



@implementation JsToIOS

+(void)ShowRewardVideo
{
    NSLog(@"Max JS调用播放视频");
    [[AdMgr getInstance]showRewardedVideo];
}
+(void)ShowInterstitial
{
    NSLog(@"Max JS调用插屏");
    [[AdMgr getInstance]showInterstitial];
}
+(void)ShowInsertAdByStartCd
{
    NSLog(@"Max JS调用插屏ShowInsertAdByStartCd");
    [[AdMgr getInstance]showInsertAdByStartCd];
}
+(void)ShowInsertAdByInterval
{
    NSLog(@"Max JS调用插屏ShowInsertAdByInterval");
    [[AdMgr getInstance]showInsertAdByInterval];
}

+(void)ShowBanner
{
    NSLog(@"Max JS调用播放横幅");
    [[AdMgr getInstance]showBanner];
}
+(void)HideBanner
{
    NSLog(@"Max JS调用隐藏横幅");
    [[AdMgr getInstance]hideBanner];
}

+(void)TrackEvent:(NSString*)eventName params:(NSString *)params
{
    NSLog(@"Max JS统计事件:%@,param:%@",eventName,params);
    if(params == nil || [params isEqualToString:@""] ){
        [FIRAnalytics logEventWithName:eventName parameters:NULL];
    }else{
        NSData *jsonData = [params dataUsingEncoding:NSUTF8StringEncoding];
        NSError *error = nil;
        NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:jsonData options:0 error:&error];
        if(error){
            NSLog(@"Max JS解析firebase参数失败:%@",error.localizedDescription);
        }else{
            NSLog(@"Max Js解析firebase参数成功，转换后的dict:%@",jsonDict);
            [AdMgr getInstance].levelnum=[jsonDict[@"level_name"] intValue];
            NSLog(@"当前关卡%d",[AdMgr getInstance].levelnum);
            [FIRAnalytics logEventWithName:eventName parameters:jsonDict];
        }
    }
}

+(void)TenjinTrackEvent:(NSString*)eventName
{
    NSLog(@"Max JS Tenjin统计事件:%@",eventName);
    [TenjinSDK sendEventWithName:eventName];
}
+(void)GetSystemLanguage{
    [[AdMgr getInstance] getSystemLanguage];
}

//+(void)Login{
//    NSLog(@"IOS登录 JsToIOS");
//    [[IOSLogin getInstance]login];
//}
//
//+(void)BuyGoods:(NSString *)productId userId:(NSString *)userId{
//    NSLog(@"IOS购买商品:%@,userId:%@",productId,userId);
//    [[IOSPurchase getInstance]requestProductInfo:productId userId:userId];
//}
//
//+(void)RestorePurchase{
//    NSLog(@"IOS恢复购买");
//    [[IOSPurchase getInstance]restorePurchases];
//}
//
//+(void)ReviewApp{
//    [SKStoreReviewController requestReview];
//}

@end
