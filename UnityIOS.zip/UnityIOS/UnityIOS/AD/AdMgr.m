//
//  AdMgr.m
//  wbxcsa-mobile
//
//  Created by 朱启奔 on 2024/9/14.
//

#import "AdMgr.h"
#import "Interstitial.h"
#import "RewardedVideo.h"

#import <Firebase.h>
#import "TenjinSDK.h"
#import "AppDelegate.h"
#import <AdjustSdk/AdjustSdk.h>
@interface AdMgr()
@property(nonatomic,strong) UIViewController *rootViewController;
@property(nonatomic, strong) Interstitial *interstitialAd;
@property(nonatomic, strong) RewardedVideo *rewardedVideoAd;
@property(nonatomic, assign) NSString *appKey ;
@property(nonatomic, assign) NSString *splashId ;
@property(nonatomic, assign) NSString *bannerId ;
@property(nonatomic, assign) NSString *interstitialId ;
@property(nonatomic, assign) NSString *rewardedVideoId ;
@property(nonatomic,assign)  int lastAdTime;//上一次看广告的时间

//当前关卡

@end

@implementation AdMgr

static AdMgr *mInstace = nil;
+ (instancetype)getInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
      mInstace = [[super allocWithZone:NULL] init];
    });
    return mInstace;
}

-(void)init:(UIViewController *)rootViewController{
    NSLog(@"Max赋值viewcontroller");
    self.rootViewController = rootViewController;
}

-(void)initSdk:(UIViewController *)rootViewController{
    NSLog(@"Max初始化");
    self.rootViewController = rootViewController;
    self.appKey = @"x'x'x'x'x'x";
    self.rewardedVideoId = @"xxxx";
    self.interstitialId = @"xxxx";
    
    //同意流程
//    ALSdkSettings *settings = [[ALSdkSettings alloc]init];
//    settings.consentFlowSettings.enabled = YES;
//    settings.consentFlowSettings.privacyPolicyURL = @"https://res.wqop2018.com/zhise/privacy/en/wbxcsa.html";
//    ALSdk *sdk = [ALSdk sharedWithKey:self.appKey settings:settings];
//    sdk.mediationProvider = @"max";
    
//    //初始化sdk
//    [ALSdk shared].mediationProvider = @"max";
////    [ALSdk shared].userIdentifier = @"USER_ID";
//    [[ALSdk shared]initializeSdkWithCompletionHandler:^(ALSdkConfiguration * _Nonnull configuration) {
//        
//    }];
    
    if([self isInSoutheastAsiaOrSouthAmerica]){
        [TenjinSDK init:@"NVSRP9D7DSC3W6VK27W3U6JFVZTGWEKC"];
        [TenjinSDK connect];
    }else{

        NSString *yourAppToken = @"dh5esj888idc";
           NSString *environment = ADJEnvironmentProduction;
           ADJConfig *adjustConfig = [[ADJConfig alloc] initWithAppToken:yourAppToken
                                                        environment:environment];
           // Your code here
        [adjustConfig setLogLevel:ADJLogLevelVerbose];
        
        [Adjust initSdk:adjustConfig];
        
        ADJEvent *event = [[ADJEvent alloc] initWithEventToken:@"9e34hk"];
           [Adjust trackEvent:event];
    }
    
    // Create the initialization configuration
     ALSdkInitializationConfiguration *initConfig = [ALSdkInitializationConfiguration configurationWithSdkKey: @"OWGTL0q2nel8rH04tF7POn4pQKwCQ2FZyBMTLSiAFAETpnoiMaFSeKQm8AM0TDJihUfI3vK4KQonpAplqOcdRq" builderBlock:^(ALSdkInitializationConfigurationBuilder *builder) {
       builder.mediationProvider = ALMediationProviderMAX;
     }];

     // Initialize the SDK with the configuration
     [[ALSdk shared] initializeWithConfiguration: initConfig completionHandler:^(ALSdkConfiguration *sdkConfig) {
         NSLog(@"Max Sdk初始化成功");
         
         //创建广告对象
         self.interstitialAd = [[Interstitial alloc]initAd:self.interstitialId rootViewController:self.rootViewController];
         self.rewardedVideoAd = [[RewardedVideo alloc]initAd:self.rewardedVideoId rootViewController:self.rootViewController];
     }];
    //测试模式
//    [[ALSdk shared]showMediationDebugger];
  
}

- (BOOL)isInSoutheastAsiaOrSouthAmerica {
    // 获取当前设备的国家/地区代码
    NSString *countryCode = [[NSLocale currentLocale] objectForKey:NSLocaleCountryCode];
    
    // 定义东南亚国家的国家代码（ISO 3166-1 alpha-2）
    NSArray *southeastAsiaCountries = @[@"IN", @"VN", @"LA", @"KH", @"TH", @"MM", @"MY", @"ID", @"BN", @"PH", @"TL"];
    
    // 定义南美国家的国家代码（ISO 3166-1 alpha-2）
    NSArray *southAmericaCountries = @[@"BR", @"AR", @"CO", @"CL", @"PE", @"BO", @"EC", @"VE", @"GY", @"SR", @"PY", @"UY"];
    
    // 判断当前国家是否属于东南亚或南美
    if ([southeastAsiaCountries containsObject:countryCode] || [southAmericaCountries containsObject:countryCode]) {
        return YES;
    } else {
        return NO;
    }
}

-(void)showBanner{
    NSLog(@"Max AdMgr showBanner");
}
-(void)hideBanner{
    NSLog(@"Max AdMgr hideBanner");
}

-(void)showInterstitial{
    NSLog(@"Max AdMgr showInterstitial");
    [self.interstitialAd show];
}

-(void)showInsertAdByStartCd{
    NSLog(@"Max AdMgr showInsertAdByStartCd");
    self.interstitialAd.levelnum=self.levelnum;
    [self.interstitialAd showByStartCd];
}
-(void)showInsertAdByInterval{
    NSLog(@"Max AdMgr showInsertAdByInterval");
    [self.interstitialAd showByInterval];
}

-(void)showRewardedVideo{
    NSLog(@"Max AdMgrshowRewardedVideo");
    if(self.rewardedVideoAd){
        [self.rewardedVideoAd show];
    }else{
        [self videoEnd:false];
    }
    
    
}

-(void)setConnState:(BOOL)isConn{
    if (isConn) {
        NSLog(@"OpenMediation 联网成功");
    }else{
        NSLog(@"OpenMediation 联网失败");
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"tips" message:@"Please turn on the network of your phone and back to the App" delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:@"ok", nil];
        [alertView show];
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSLog(@"OpenMediation 点击%d",buttonIndex);
    if (buttonIndex == 0) {
        NSLog(@"OpenMediation 对话框取消");
        exit(0);
    }else{
        NSLog(@"OpenMediation 对话框确认");
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
    }
}

-(int)getCurTime{
    NSDate *now = [NSDate date];
    return (int)[now timeIntervalSince1970];
}

//-(NSString *)getSystemLanguage{
//    NSString *lan = [[NSLocale preferredLanguages]objectAtIndex:0];
//    if ([lan rangeOfString:@"zh-Hans"].location != NSNotFound) {
//        NSLog(@"当前语言是简体中文");
//        [self.rootViewController CallJs:@"zs.Native.onGetLanguage(\"zh\")"];
//    } else if ([lan rangeOfString:@"zh-Hant"].location != NSNotFound) {
//        NSLog(@"当前语言是繁体中文");
//        [self.rootViewController CallJs:@"zs.Native.onGetLanguage(\"ft\")"];
//    } else{
//        NSLog(@"当前语言是英语");
//        [self.rootViewController CallJs:@"zs.Native.onGetLanguage(\"en\")"];
//    }
//}
//
-(void)videoEnd:(BOOL)res{
    AppDelegate *appDelegate = (AppDelegate *)([UIApplication sharedApplication].delegate);
    if (res) {
        [appDelegate sendMessageWithName:[@"AndroidAdMono" UTF8String]
                             functionName:[@"OnVideoClose" UTF8String]
                                  message:[@"true" UTF8String]];

    }else{
        [appDelegate sendMessageWithName:[@"AndroidAdMono" UTF8String]
                             functionName:[@"OnVideoClose" UTF8String]
                                  message:[@"false" UTF8String]];
    }
    
}
//
//-(void)interstitialShowCb{
//    [self.rootViewController CallJs:@"zs.Native.onInterstitialShow()"];
//}
//
//-(void)interstitialCloseCb{
//    [self.rootViewController CallJs:@"zs.Native.onInterstitialClose()"];
//}

-(void)setLastAdTime{
    _lastAdTime = [self getCurTime];
}
-(int)getLastAdTime{
    return self.lastAdTime;
}

- (void)interstitialCloseCb {
}

- (void)interstitialShowCb {
}

- (void)showSplash {
}



@end
