//
//  Fbinitialize.h
//  Unity-iPhone
//
//  Created by 发行二部 on 2024/12/5.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <FBSDKCoreKit/FBSDKCoreKit.h>
NS_ASSUME_NONNULL_BEGIN

@interface Fbinitialize : NSObject
+ (void)fbinitalize:(UIApplication *)application :(NSDictionary *)launchOptions;

+(void)Netjudgment;
@end

NS_ASSUME_NONNULL_END
