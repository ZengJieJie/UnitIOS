//
//  Interstitial.m
//  wbxcsa-mobile
//
//  Created by 朱启奔 on 2024/9/14.
//
#import "Interstitial.h"
#import <AppLovinSDK/AppLovinSDK.h>
#import "AdMgr.h"
#import <AdjustSdk/AdjustSdk.h>
@interface Interstitial()<MAAdDelegate>
@property(nonatomic, strong) UIViewController *rootViewController;
@property(nonatomic, strong) MAInterstitialAd *interstitialAd;
@property(nonatomic, assign) NSInteger retryAttempt;

@property(nonatomic,assign)  int *lastInterstitialTime;
@property(nonatomic,assign)  int *startTime;
@end

@implementation Interstitial
    
-(instancetype)initAd:(NSString *)adSlotId rootViewController:(UIViewController *)rootViewController
{
    NSLog(@"Max interstitial 初始化");
    self.interstitialAd = [[MAInterstitialAd alloc]initWithAdUnitIdentifier:adSlotId];
    self.interstitialAd.delegate = self;
    [self.interstitialAd loadAd];
    
    self.startTime = [[AdMgr getInstance]getCurTime];
    NSString *timeSp = [NSString stringWithFormat:@"%d",self.startTime];
    NSLog(@"OpenMediarion 启动时间戳：%@",timeSp);
    return self;
}

- (void)didLoadAd:(MAAd *)ad{
    NSLog(@"Max Interstitial加载成功");
    self.retryAttempt = 0;
}

- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withError:(MAError *)error{
    NSLog(@"Max Interstitial加载失败：%d %@",error.code,error.message);
    self.retryAttempt++;
    NSInteger delaySec = pow(2, MIN(6,self.retryAttempt));
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, delaySec*NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        [self.interstitialAd loadAd];
    });
}

- (void)didDisplayAd:(MAAd *)ad{
    NSLog(@"Max Interstitial展示成功");
    self.lastInterstitialTime = [[AdMgr getInstance]getCurTime];
}

- (void)didHideAd:(MAAd *)ad{
    NSLog(@"Max Interstitial隐藏");
    [[AdMgr getInstance] setLastAdTime];
    [[AdMgr getInstance]interstitialShowCb];
    [[AdMgr getInstance]interstitialCloseCb];
    [self.interstitialAd loadAd];
}
- (void)didPayRevenueForAd:(MAAd *)ad
{
    double revenue = ad.revenue; // In USD
    
    // Miscellaneous data
    NSString *countryCode = [ALSdk shared].configuration.countryCode; // "US" for the United States, etc - Note: Do not confuse this with currency code which is "USD"
    NSString *networkName = ad.networkName; // Display name of the network that showed the ad
    NSString *adUnitId = ad.adUnitIdentifier; // The MAX Ad Unit ID
    MAAdFormat *adFormat = ad.format; // The ad format of the ad (e.g. BANNER, MREC, INTERSTITIAL, REWARDED)
    NSString *placement = ad.placement; // The placement this ad's postbacks are tied to
    NSString *networkPlacement = ad.networkPlacement; // The placement ID from the network that showed the ad
    NSLog(@"收入-%.7f-地区-%@-广告名-%@-Unit ID-%@-广告形式-%@-位置-%@-放置ID-%@", revenue,countryCode,networkName,adUnitId,adFormat,placement,networkPlacement);
    ADJAdRevenue *adRevenue = [[ADJAdRevenue alloc]
                               initWithSource:@"applovin_max_sdk"];
    [adRevenue setRevenue:revenue currency:@"USD"];
    [adRevenue setAdImpressionsCount:10];
    [adRevenue setAdRevenueNetwork:adFormat.label];
    [adRevenue setAdRevenueUnit:ad.adUnitIdentifier];
    [adRevenue setAdRevenuePlacement:[ALSdk shared].configuration.countryCode];
    [Adjust trackAdRevenue:adRevenue];
}
- (void)didFailToDisplayAd:(MAAd *)ad withError:(MAError *)error{
    NSLog(@"Max Interstitial展示失败：%d %@",error.code,error.message);
}

-(void)show
{
    int curTime = [[AdMgr getInstance]getCurTime];
    NSLog(@"curTime:%d",curTime);
    int lastAdTime =(int)([[AdMgr getInstance] getLastAdTime]);
    NSLog(@"lastAdTime:%d",lastAdTime);
    int sub2 = curTime - lastAdTime;
    NSLog(@"Max广告间隔:%d",sub2);
    if(sub2 < 50){
        NSLog(@"Max Interstitial show距离上次广告不足30秒，不展示");
        return;
    }
    [self.interstitialAd showAd];
//    if([self.interstitialAd isReady]){
//        [self.interstitialAd showAd];
//    }else{
//        NSLog(@"Max Interstitial未准备好");
//    }
}
/**暂时没用**/
-(void)showByStartCd{
    NSLog(@"Max Interstitial showByStartCd");
    int curTime = [[AdMgr getInstance]getCurTime];
    int sub = (int)curTime - (int)(self.startTime) ;
    if (self.levelnum>5) {
//        if(sub >= 300 ){
            [self show];
//        }else{
//            NSLog(@"Max Interstitial showByStartCd启动不足300秒，不展示");
//        }
    }else{
        NSLog(@"Max Interstitial 关卡5之后展示插屏，不展示");
    }
    
}
/**暂时没用**/
- (void)showByInterval{
    NSLog(@"Max Interstitial showByInterval");
    int curTime = [[AdMgr getInstance]getCurTime];
    NSString *timeSp = [NSString stringWithFormat:@"%d",curTime];
    NSLog(@"Max 当前时间戳：%@",timeSp);
    int sub = (int)curTime - (int)(self.startTime) ;
    NSLog(@"Max时间差1：%d",sub);
     if(sub < 300 ){
         NSLog(@"Max Interstitial showByInterval启动不足300秒，不展示");
         return;
     }
    int sub2 = (int)(curTime) - (int)(self.lastInterstitialTime);
    NSLog(@"Max时间差2：%d",sub);
     if(sub2 < 200){
         NSLog(@"Max Interstitial showByInterval距离上次插屏不足200秒，不展示");
         return;
     }
    [self show];
}


@end
