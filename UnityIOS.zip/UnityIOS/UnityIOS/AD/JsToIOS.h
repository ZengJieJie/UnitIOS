//
//  JsToIOS.h
//  wbxcsa-mobile
//
//  Created by 朱启奔 on 2024/10/30.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface JsToIOS : NSObject
@property (assign, nonatomic) int levelnum;
+(void)TrackEvent:(NSString*)eventName params:(NSString *)params;
+(void)ShowInsertAdByStartCd;
+(void)ShowRewardVideo;
@end

NS_ASSUME_NONNULL_END
