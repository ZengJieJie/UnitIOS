//
//  Interstitial.h
//  wbxcsa-mobile
//
//  Created by 朱启奔 on 2024/9/14.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Interstitial : NSObject
-(instancetype)initAd:(NSString *)adSlotId rootViewController:(UIViewController *)rootViewController;
-(void)show;//不考虑时间，调用了就会弹、展示
-(void)showByStartCd;//启动前多少秒不会展示
-(void)showByInterval;//启动前多少秒不会展示，而且两次插屏之间有时间间隔
@property(nonatomic,assign)  int levelnum;
@end
NS_ASSUME_NONNULL_END
