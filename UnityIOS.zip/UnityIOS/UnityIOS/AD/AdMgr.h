//
//  AdMgr.h
//  wbxcsa-mobile
//
//  Created by 朱启奔 on 2024/9/14.
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <AppLovinSDK/AppLovinSDK.h>
NS_ASSUME_NONNULL_BEGIN

@interface AdMgr : NSObject
+(instancetype)getInstance;
-(void)init:(UIViewController *)rootViewController;
-(void)initSdk:(UIViewController *)rootViewController;
-(void)showSplash;
-(void)showBanner;
-(void)hideBanner;
-(void)showInterstitial;
-(void)showInsertAdByStartCd;
-(void)showInsertAdByInterval;
-(void)showRewardedVideo;
-(void)setConnState:(BOOL)isConn;
-(int)getCurTime;
-(NSString *)getSystemLanguage;
-(void)videoEnd:(BOOL)res;
-(void)interstitialShowCb;
-(void)interstitialCloseCb;
-(void)setLastAdTime;
-(int)getLastAdTime;
@property(nonatomic,assign)  int levelnum;
@end

NS_ASSUME_NONNULL_END
